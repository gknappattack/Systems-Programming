#include "sbuf.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>

#define MAX_OBJECT_SIZE 102400
#define HTTP_REQUEST_MAX_SIZE 4096
#define HOSTNAME_MAX_SIZE 512
#define PORT_MAX_SIZE 6
#define URI_MAX_SIZE 4096
#define METHOD_SIZE 32
#define BUF_SIZE 500
#define MAXLINE 6000
#define NTHREADS  100
#define SBUFSIZE  20

void *thread(void *vargp);


int is_complete_request(const char *request) {
    printf("Checking validity of request\n");
	char *ret = strstr(request, "\r\n\r\n");
	if (ret != NULL) {
		return 1;
	}

	printf("Invalid request\n");
	return 0;
}

void get_remaining_headers(char *headers, const char *request) {

    char *token;
    char *requestcopy = malloc(sizeof(request));
    strcpy(requestcopy, request);

    /* get the first token */
    token = strtok(requestcopy, "\r\n");

    //Ignore first line of headers
    token = strtok(NULL, "\r\n");

    int headerslen = 0;

    /* walk through other tokens */
    while( token != NULL ) {
        //Initialize variables for parsing header name
        char headername[100];
        char *headernameend = strchr(token, ':');

        //Initialize variable to store parsed name
        char currheader[100];

        //Copy token to append to headers if needed
        strcpy(currheader, token);

        //Split token at colon to isolate header name
        *headernameend = '\0';
        strcpy(headername, token);

        //Check if token is one we can skip over
        if (strcmp(headername, "Host") == 0 || strcmp(headername, "User-Agent") == 0 ||
        strcmp(headername, "Proxy-Connection") == 0 || strcmp(headername, "Connection") == 0) {
            //Do nothing
        }
        else {
            //Copy full header
            strcpy(headers+headerslen, currheader);

            //Add headerslen to keep track of string array
            headerslen += strlen(currheader);

            //Append carriage return to end of string
            strcpy(headers+headerslen, "\r\n");

            //update headerslen to get next header
            headerslen += 2;
        }
        token = strtok(NULL, "\r\n");
    }

    //Append second carriage return for end of request
    strcpy(headers+headerslen, "\r\n");

    free(requestcopy);
}

int parse_request(const char *request, char *method,
		char *hostname, char *port, char *uri, char *headers) {
	//int complete = is_complete_request(request);

	//if (complete == 1) {
	    //Sscanf to get the individual headers
	    char *hostport = calloc(HTTP_REQUEST_MAX_SIZE, sizeof(char));
	    char *version = calloc(HTTP_REQUEST_MAX_SIZE, sizeof(char));
	    sscanf(request, "%s %s %s\r\n", method, hostport, version);

	    //Identify where hostname starts and where port ends
	    char *begin = strstr(hostport, "//") + 2;
	    char *end = strchr(begin, '/');

	    *end = '\0';

	    //Copy host name and uri separately
	    strcpy(hostname, begin);
	    strcpy(uri, end+1);

	    //Check if there is a port
	    char *portstart = strchr(begin, ':');
	    if (portstart == NULL) {
	        strcpy(port, "80");
	    }
	    else {
	        strcpy(port, portstart+1);
			char *hostend = strstr(hostname, port) - 1;
			*hostend = '\0';

	    }

	    get_remaining_headers(headers, request);
	//}

	printf("URI\n");
	printf("%s\n", uri);

	return 1;
}


/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";
sbuf_t sbuf;

int main(int argc, char *argv[])
{

    //Variables for connecting to client
    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_in ip4addr;
    struct sockaddr_storage clientaddr;

	//Variables for concurrency
	pthread_t tid;


	if (argc < 2) {
		fprintf(stderr, "Usage: %s port\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	sbuf_init(&sbuf, SBUFSIZE); //line:conc:pre:initsbuf
	for (int i = 0; i < NTHREADS; i++)  /* Create worker threads */ //line:conc:pre:begincreate
		pthread_create(&tid, NULL, thread, NULL);   

    ip4addr.sin_family = AF_INET;
    ip4addr.sin_port = htons(atoi(argv[1]));
    ip4addr.sin_addr.s_addr = INADDR_ANY;

    //Listen for connection - TODO: does this go in while loop?
    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket error");
        exit(EXIT_FAILURE);
    }

    //bind
    if (bind(listenfd, (struct sockaddr*)&ip4addr, sizeof(struct sockaddr_in)) < 0) {
        close(listenfd);
        perror("bind error");
        exit(EXIT_FAILURE);
    }

    if (listen(listenfd, 100) < 0) {
        close(listenfd);
        perror("listen error");
        exit(EXIT_FAILURE);
    }           /* No longer needed */

    printf("New proxy started\n");

	while (1) {
		clientlen = sizeof(struct sockaddr_storage);
		connfd = accept(listenfd, (struct sockaddr *) &clientaddr, &clientlen);
		sbuf_insert(&sbuf, connfd);
	}

    return 0;
}


void *thread(void *vargp) 
{  
	pthread_detach(pthread_self()); 
	//Values for saving and sending requests
    char *request;
    char *requesttosend;

    //Buffers for values from request
    char *method;
    char *hostname;
    char *port;
    char *uri;
    char *headers;

	//Variables for client connection to web server
    int webserverfd;
    struct sockaddr_in webserver;

	while (1) { 
		int connfd = sbuf_remove(&sbuf);

		//Values for saving and sending requests
        request = calloc(BUFSIZ, sizeof(char));
        requesttosend = calloc(MAXLINE, sizeof(char));

        //Buffers for values from request
        method = calloc(METHOD_SIZE + 1, sizeof(char));
        hostname = calloc(HOSTNAME_MAX_SIZE + 1, sizeof(char));
        port = calloc(PORT_MAX_SIZE + 1, sizeof(char));
        uri = calloc(URI_MAX_SIZE + 1, sizeof(char));
        headers = calloc(BUF_SIZE + 1, sizeof(char));


        char *serverresponse = calloc(MAX_OBJECT_SIZE, sizeof(char));
        int serverresponselen = 0;

		int bytesread = 0;
		int totalread = 0;

		while (is_complete_request(request) == 0) {
		    bytesread = recv(connfd, request+totalread, BUF_SIZE, 0);
		    totalread += bytesread;
		}

        int validrequest = parse_request(request, method, hostname, port, uri, headers);
        if (validrequest) {
            int bufferlocation = 0;

            //Assemble headers
            bufferlocation = sprintf(requesttosend, "%s /%s HTTP/1.0\r\n", method, uri);
            bufferlocation += sprintf(requesttosend+bufferlocation, "Host: %s\r\n", hostname);
            bufferlocation += sprintf(requesttosend+bufferlocation, "User-Agent: %s", user_agent_hdr);
            bufferlocation += sprintf(requesttosend+bufferlocation, "Connection: close\r\n");
            bufferlocation += sprintf(requesttosend+bufferlocation, "Proxy-Connection: close\r\n");
            sprintf(requesttosend+bufferlocation, "%s", headers);
            printf("%s\n", requesttosend);

            webserverfd = socket(AF_INET, SOCK_STREAM, 0);
            if (webserverfd ==  -1) {
                printf("could not create socket\n");
            }

            webserver.sin_family = AF_INET;
            webserver.sin_port = htons(atoi(port));
            webserver.sin_addr.s_addr = INADDR_ANY;


            if (connect(webserverfd, (struct sockaddr *)&webserver, sizeof(webserver)) < 0) {
                printf("Connection failed\n");
            }
            else {

                send(webserverfd, requesttosend, strlen(requesttosend), 0);


                while (1) {
                    int bytesread = 0;
                    bytesread = recv(webserverfd, serverresponse+serverresponselen, 2000, 0);

                    serverresponselen += bytesread;

                    if (bytesread == 0) {
                        break;
                    }
                }
				send(connfd, serverresponse, serverresponselen,0);
            }

        }

        free(request);
        free(requesttosend);
        free(method);
        free(hostname);
        free(port);
        free(uri);
        free(headers);

		close(connfd);
	}
}

