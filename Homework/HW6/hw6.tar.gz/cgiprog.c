#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAXLINE 4000

int main(int argc, char *argv[], char *envp[]) {
	char *buf;
	char content[MAXLINE];

	if ((buf = getenv("QUERY_STRING")) == NULL) {
		printf("Query String not found\n");
		exit(1);
	}

	sprintf(content, "The query string is: %s", buf);

	printf("Content-length: %d\r\n", (int)strlen(content));
	printf("Content-type: text/plain\r\n\r\n");
	printf("%s\r\n", content);
	fflush(stdout);

	exit(0);
}
