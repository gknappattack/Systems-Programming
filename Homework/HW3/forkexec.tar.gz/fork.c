#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int argc, char *argv[]) {
	int pid;
	int fd[2];
	FILE *fp;

	pipe(fd);

	fp = fopen("fork-output.txt", "w");

	printf("Starting program; process has pid %d\n", getpid());

	fputs("BEFORE FORK\n", fp);
	if ((pid = fork()) < 0) {
		fprintf(stderr, "Could not fork()");
		exit(1);
	}

	/* BEGIN SECTION A */

	printf("Section A;  pid %d\n", getpid());
	fputs("SECTION A\n", fp);

	/* END SECTION A */
	if (pid == 0) {
		/* BEGIN SECTION B */
		close(fd[0]);

		FILE *stream;
		stream = fdopen(fd[1], "w");
		fputs("hello from Section B\n", stream);

		printf("Section B\n");
		fputs("SECTION B\n", fp);
		printf("Section B done sleeping\n");

		//Body of exec.c
		char *newenviron[] = { NULL };

		printf("Program \"%s\" has pid %d. Sleeping.\n", argv[0], getpid());

		if (argc <= 1) {
			printf("No program to exec.  Exiting...\n");
			exit(0);
		}
		
		int dupFD = fileno(fp);
		dup2(dupFD, 1);

		printf("Running exec of \"%s\"\n", argv[1]);
		execve(argv[1], &argv[1], newenviron);
		printf("End of program \"%s\".\n", argv[0]);


		exit(0);

		/* END SECTION B */
	} else {
		/* BEGIN SECTION C */
		close(fd[1]);

		FILE *stream;
		stream = fdopen(fd[0], "r");
		char readString[32];
		fgets(readString, 32, stream);
		fprintf(stdout, "%s\n", readString);

		printf("Section C\n");
		fputs("SECTION C\n", fp);

		waitpid(-1,NULL, 0);
		printf("Section C done sleeping\n");

		exit(0);

		/* END SECTION C */
	}
	/* BEGIN SECTION D */

	printf("Section D\n");
	fputs("SECTION D\n", fp);

	/* END SECTION D */
}
